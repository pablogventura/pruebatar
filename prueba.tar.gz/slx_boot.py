
import machine
import neopixel
import time

led=neopixel.NeoPixel(machine.Pin(8),1)

while True:
    led[0] = (0,0,0)
    led.write()
    time.sleep(0.5)
    led[0] = (0,0,255)
    led.write()
    time.sleep(0.5)

# import network
# import webrepl
# #import wifi_connect
# import config.wifi_cfg as wifi_cfg
# import slx_sys.communication.slx_wifi_client as slx_wifi_client
# import slx_sys.communication.slx_wifi_ap as slx_wifi_ap
# import slx_sys.communication.slx_requests as slx_requests

# if wifi_cfg.MODE == 'CL':
#     slx_requests.networks_list.append(slx_wifi_client.WIFI_Client())
# else:
#     slx_wifi_ap.WIFI_AP().active()

# print("Iniciando WebREPL")
# webrepl.start()

# import slx_sys.slx_task_scheduler as slx_task_scheduler
# #import slx_sys.gurux.dispatcher_run as dispatcher_run
